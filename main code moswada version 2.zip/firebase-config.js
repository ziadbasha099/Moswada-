/* ============================================================
   Firebase configuration — shared by downloads.html و admin.html
   ------------------------------------------------------------
   عدّل القيم بالأسفل بإعدادات مشروعك في Firebase:
   Firebase Console → Project settings → General → Your apps
   → SDK setup and configuration → Config

   راجع ملف README-Firebase-Setup.md لخطوات الإعداد كاملة
   (إنشاء المشروع، تفعيل Authentication و Firestore، وإنشاء
   حساب المدير).
   ============================================================ */

export const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

/* اسم مجموعة (collection) الروابط في Firestore — لا تغيّره إلا إذا
   غيّرته في القاعدة أيضاً */
export const DOWNLOADS_COLLECTION = "downloads";
